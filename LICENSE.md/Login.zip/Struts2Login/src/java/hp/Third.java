/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hp;

/**
 *
 * @author Brajraj Singh
 */
public class Third {
    
    public Third() {
    }
    
    public String execute() throws Exception {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
