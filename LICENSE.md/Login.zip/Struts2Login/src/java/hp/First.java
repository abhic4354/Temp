/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hp;

import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.Interceptor;

/**
 *
 * @author Brajraj Singh
 */
public class First implements Interceptor {
    
    public First() {
    }
    
    public void destroy() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
    public void init() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
    public String intercept(ActionInvocation actionInvocation) throws Exception {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
