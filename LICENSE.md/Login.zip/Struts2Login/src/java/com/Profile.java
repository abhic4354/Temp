/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com;
import javax.servlet.http.HttpServletRequest;  
import javax.servlet.http.HttpSession;  
import org.apache.struts2.ServletActionContext;  
/**
 *
 * @author Brajraj Singh
 */
public class Profile {
    
    public Profile() {
    }
    
    public String execute() throws Exception {
HttpServletRequest request=ServletActionContext.getRequest();  
HttpSession session=request.getSession();  
  
String s=(String)session.getAttribute("login");  
if(s!=null && !s.equals("")){  
    return "success";  
}  
else{  
    return "error";  
}  
  
}  
}
