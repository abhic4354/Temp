/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com;

import com.opensymphony.xwork2.ActionSupport;

/**
 *
 * @author Brajraj Singh
 */
public class Sec extends ActionSupport {
    
    public Sec() {
    }
    
    public String execute() throws Exception {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
