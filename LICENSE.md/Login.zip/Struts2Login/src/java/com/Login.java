/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com;
//import com.sun.faces.context.SessionMap;
import java.util.Map;  
import org.apache.struts2.dispatcher.SessionMap;  
import org.apache.struts2.interceptor.SessionAware;   
/**
 *
 * @author Brajraj Singh
 */
public class Login  implements SessionAware {
    
    private String username,userpass;  
    SessionMap<String,String> sessionmap;

    public Login() {
    }
     /**
     * @return the username
     */
    public String getUsername() {
        return username;
    }

    /**
     * @param username the username to set
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * @return the userpass
     */
    public String getUserpass() {
        return userpass;
    }

    /**
     * @param userpass the userpass to set
     */
    public void setUserpass(String userpass) {
        this.userpass = userpass;
    }

    /**
     * @return the sessionmap
     */
    public SessionMap<String,String> getSessionmap() {
        return sessionmap;
    }

   
     public String execute() throws Exception 
     {
        //throw new UnsupportedOperationException("Not supported yet.");
         if(com.LoginDao.validate(getUsername(), getUserpass()))
         {  
        return "success";  
         }  
    else
         {  
        return "error";  
         }
     }
         public void setSession(Map<String, Object> map)
         {
           //throw new UnsupportedOperationException("Not supported yet.");
             sessionmap=(SessionMap)map;  
             sessionmap.put("login","true");
         }
  
        public String logout()
        {  
          sessionmap.invalidate();  
          return "success";  
        }

   
         
    
}
